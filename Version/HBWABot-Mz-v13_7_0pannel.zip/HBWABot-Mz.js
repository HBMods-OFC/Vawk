/*
   HBWABot-Mz.js Install 
   Script by Herbert Suantak
*/